# Meme Marketplace Platform

A full-stack web application that connects brands with influencers for meme-based marketing campaigns. This platform enables brands to create promotional campaigns and influencers to apply for these opportunities, fostering a collaborative ecosystem for viral marketing.

## 🚀 Features

### For Brands

- **User Registration & Authentication**: Secure signup and login system
- **Campaign Management**: Create, edit, and manage promotional campaigns
- **Influencer Discovery**: Browse and search through verified influencers
- **Application Review**: Review and approve influencer applications
- **Real-time Messaging**: Direct communication with influencers
- **Analytics Dashboard**: Track campaign performance and metrics

### For Influencers

- **Profile Management**: Create detailed profiles with social media links
- **Portfolio Showcase**: Upload and display previous work samples
- **Campaign Applications**: Apply for relevant promotional opportunities
- **Pricing Management**: Set and manage service rates
- **Verification System**: Get verified status for credibility
- **Messaging System**: Communicate directly with brands

### Technical Features

- **Responsive Design**: Mobile-first approach with Tailwind CSS
- **Real-time Updates**: Live notifications and status updates
- **File Upload System**: Support for images, videos, and documents via Cloudinary
- **Secure Authentication**: JWT-based authentication with bcrypt password hashing
- **RESTful API**: Well-structured backend with modular architecture

## 🛠️ Tech Stack

### Frontend

- **React 19** - Modern React with latest features
- **Tailwind CSS** - Utility-first CSS framework
- **React Router DOM** - Client-side routing
- **Axios** - HTTP client for API calls
- **Framer Motion** - Animation library
- **React Hot Toast** - Notification system
- **Lucide React** - Icon library
- **Vite** - Fast build tool and dev server

### Backend

- **Node.js** - JavaScript runtime
- **Express.js** - Web application framework
- **MongoDB** - NoSQL database
- **Mongoose** - MongoDB object modeling
- **JWT** - JSON Web Tokens for authentication
- **bcryptjs** - Password hashing
- **Cloudinary** - Cloud-based media management
- **Multer** - File upload handling
- **CORS** - Cross-origin resource sharing

## 📋 Prerequisites

Before running this project, make sure you have the following installed:

- **Node.js** (v16 or higher)
- **npm** or **yarn** package manager
- **MongoDB** (local installation or MongoDB Atlas account)
- **Cloudinary** account (for media uploads)

## 🔧 Installation & Setup

### 1. Clone the Repository

```bash
git clone https://github.com/VamshiMudiraj05/MemeProject.git
cd MemeProject
```

### 2. Backend Setup

```bash
cd backend
npm install
```

Create a `.env` file in the backend directory:

```env
# Database
MONGODB_URI=mongodb://localhost:27017/meme_project
# or for MongoDB Atlas: mongodb+srv://username:password@cluster.mongodb.net/meme_project

# JWT Secret
JWT_SECRET=your_jwt_secret_key_here

# Cloudinary Configuration
CLOUDINARY_CLOUD_NAME=your_cloudinary_cloud_name
CLOUDINARY_API_KEY=your_cloudinary_api_key
CLOUDINARY_API_SECRET=your_cloudinary_api_secret

# Server Configuration
PORT=5000
NODE_ENV=development
```

### 3. Frontend Setup

```bash
cd ../frontend
npm install
```

Create a `.env` file in the frontend directory:

```env
VITE_API_URL=http://localhost:5000/api
```

### 4. Database Setup

Make sure MongoDB is running on your system or use MongoDB Atlas.

## 🚀 Running the Application

### Development Mode

1. **Start the Backend Server**

```bash
cd backend
npm run dev
```

The backend server will start on `http://localhost:5000`

2. **Start the Frontend Development Server**

```bash
cd frontend
npm run dev
```

The frontend will start on `http://localhost:5173`

### Production Mode

1. **Build the Frontend**

```bash
cd frontend
npm run build
```

2. **Start the Backend in Production**

```bash
cd backend
npm start
```

## 📁 Project Structure

```
meme_project/
├── backend/
│   ├── src/
│   │   ├── controllers/     # API route handlers
│   │   ├── middleware/      # Authentication & validation
│   │   ├── models/          # Database models
│   │   ├── routes/          # API routes
│   │   ├── config/          # Database & Cloudinary config
│   │   └── server.js        # Main server file
│   └── package.json
├── frontend/
│   ├── src/
│   │   ├── components/      # Reusable React components
│   │   ├── pages/           # Page components
│   │   ├── contexts/        # React contexts
│   │   ├── services/        # API service functions
│   │   └── utils/           # Utility functions
│   └── package.json
└── README.md
```

## 🔐 Environment Variables

### Backend (.env)

- `MONGODB_URI` - MongoDB connection string
- `JWT_SECRET` - Secret key for JWT tokens
- `CLOUDINARY_CLOUD_NAME` - Cloudinary cloud name
- `CLOUDINARY_API_KEY` - Cloudinary API key
- `CLOUDINARY_API_SECRET` - Cloudinary API secret
- `PORT` - Server port (default: 5000)

### Frontend (.env)

- `VITE_API_URL` - Backend API URL

## 📱 API Endpoints

### Authentication

- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `GET /api/auth/profile` - Get user profile

### Promotions

- `GET /api/promotions` - Get all promotions
- `POST /api/promotions` - Create new promotion
- `PUT /api/promotions/:id` - Update promotion
- `DELETE /api/promotions/:id` - Delete promotion

### Applications

- `GET /api/applications` - Get applications
- `POST /api/applications` - Submit application
- `PUT /api/applications/:id` - Update application status

### Messaging

- `GET /api/messages` - Get messages
- `POST /api/messages` - Send message

## 🎨 Key Components

### Frontend Components

- **LandingPage** - Homepage with hero section
- **BrandDashboard** - Brand management interface
- **InfluencerDashboard** - Influencer management interface
- **CreatePromotionPage** - Campaign creation form
- **InfluencerListPage** - Browse influencers
- **ConversationsPage** - Messaging interface

### Backend Models

- **User** - User authentication and profile
- **Brand** - Brand-specific information
- **Influencer** - Influencer profiles and verification
- **Promotion** - Campaign details and requirements
- **Application** - Application submissions
- **Message** - Real-time messaging system

## 🚀 Deployment

### Backend Deployment (Railway/Heroku)

1. Connect your GitHub repository
2. Set environment variables in the deployment platform
3. Deploy the backend

### Frontend Deployment (Vercel/Netlify)

1. Connect your GitHub repository
2. Set build command: `npm run build`
3. Set output directory: `dist`
4. Set environment variables

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 👨‍💻 Author

**Vamshi Mudiraj**

- GitHub: [@VamshiMudiraj05](https://github.com/VamshiMudiraj05)
- LinkedIn: [Your LinkedIn Profile]

## 🙏 Acknowledgments

- React team for the amazing framework
- Tailwind CSS for the utility-first CSS approach
- MongoDB for the flexible database solution
- Cloudinary for media management services

---

**Note**: Make sure to replace placeholder values in environment variables with your actual credentials before running the application.
